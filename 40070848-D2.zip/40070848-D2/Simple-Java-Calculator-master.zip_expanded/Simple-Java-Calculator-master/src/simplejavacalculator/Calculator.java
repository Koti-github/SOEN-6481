package simplejavacalculator;
	
/**
 * This class has all the mathematical operations defined and functions such as square root is defined.
 * This class defines the scientific calculator without using any java built in functions.
 * @author KoteswaraRaoKothamasu
 *
 */
public class Calculator {
    public enum BiOperatorModes {
        normal, add, minus, multiply, divide
        
    }
    


    private Double num1, num2;
    private Double sr;
    private Double silRec;
    private BiOperatorModes mode = BiOperatorModes.normal;
   

    private Double calculateBiImpl() {
        if (mode == BiOperatorModes.normal) {
            return num2;
        }
        if (mode == BiOperatorModes.add) {
            return add(num1,num2);
        }
        if (mode == BiOperatorModes.minus) {
            return minus(num1, num2);
        }
        if (mode == BiOperatorModes.multiply) {
            return multiply(num1,num2);
        }
        if (mode == BiOperatorModes.divide) {
            return divide(num1, num2);
        }

        // never reach 
        
        
        throw new Error();
    }
    /**
     * This method is used to add numbers
     * @param n1
     * @param n2
     * @return
     */
    public Double add(Double n1, Double n2) {
		return n1+n2;
	}
    /**
     * This method is used to subtract two numbers
     * @param n1
     * @param n2
     * @return
     */
    public Double minus(Double n1, Double n2) {
		return n1-n2;
	}
    /**
     * This method is used to divide two numbers
     * @param n1
     * @param n2
     * @return
     */
    public Double divide(Double n1, Double n2) {
		return n1/n2;
	}
    /**
     * This method is used to multiply two numbers.
     * @param n1
     * @param n2
     * @return
     */
    public Double multiply(Double n1, Double n2) {
		return n1*n2;
	}
    
    /**
     * This method invokes the right operation based on the iunput provided.
     * @param newMode
     * @param num
     * @return
     */
    public Double calculateBi(BiOperatorModes newMode, Double num) {
        if (mode == BiOperatorModes.normal) {
            num2 = 0.0;
            num1 = num;
            mode = newMode;
            return Double.NaN;
        } else {
            num2 = num;
            num1 = calculateBiImpl();
            mode = newMode;
            return num1;
        }
    }

    public Double calculateEqual(Double num) {
        return calculateBi(BiOperatorModes.normal, num);
    }
    /**
     * This method handles the Clear functionality.
     * @return normal state clear display
     */
    public Double reset() {
        num2 = 0.0;
        num1 = 0.0;
        mode = BiOperatorModes.normal;

        return Double.NaN;
    }
    /**
     * This method calculates the silver ratio constant which is equal to 2.4142135623 approximately using alternate formula suggested by google.
     * @return
     */
    public double sr() {
    	sr = (2+squareRoot(8))/2;
    	return sr;
    }
    /**
     * This method is used to deal the application of the silver ratio functionality such as to find out the corresponding width of silver 
     * rectangle which is in the ratio 1:(1+sqrt2)
     * @param inp
     * @return Silver rectangle corresponding length 
     */
    public double silverRectangle(double inp) {
    	silRec = inp*sr();
		return silRec;
    }
    /**
     * This method is used to calculate the square root of any number .
     * @param number
     * @return
     */
    public  double squareRoot(int number) {
    	double temp;

    	double sqr = number / 2;

    	do {
    		temp = sqr;
    		sqr = (temp + (number / temp)) / 2;
    	} while ((temp - sqr) != 0);

    	return sqr;
        }

}



