package simplejavacalculator;

import static org.junit.Assert.*;

import org.junit.Test;

public class SqrtTest {
	
	public double sr = 2.4142135623;
	Calculator c = new Calculator();
	@Test
	public void squareRoottest() {
		int a= (int)c.squareRoot(16);
		assertEquals(4, a);
	}
	
	
	@Test
	public void silRecTest() {
		System.out.println(1);
		double s = c.silverRectangle(1.0);
		System.out.println(2);
		double sr = Math.round(s);
		System.out.println(sr);
		assertEquals(5,sr,0);
		}
	
	@Test
	public void addTest() {
		double a = c.add(8.5,5.5);
		assertEquals(14.0, a,1);
	}
	
	@Test
	public void minusTest() {
		double m = c.minus(8.5, 6.5);
		assertEquals(2, m,1);
	}
	
	@Test
	public void divideTest() {
		double d = c.divide(8.0, 2.0);
		assertEquals(4, d,1);
	}
	
	public void multiplyTest() {
		double mu = c.multiply(4.0, 2.0);
		assertEquals(8.0, mu,1);
	}
}











