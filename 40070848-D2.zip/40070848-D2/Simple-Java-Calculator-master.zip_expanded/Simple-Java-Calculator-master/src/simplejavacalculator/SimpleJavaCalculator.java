/**
 * 
 * @author KoteswaraRaoKothamasu
 * @date 02_Aug_2019
 * 
 * This package includes all the objects necessary for ETERNITY numbers calculator
 * This class has main method which  calls the internal functions.
 */
		
 
package simplejavacalculator;

public class SimpleJavaCalculator {

    public static void main(String[] args) {
        UI uiCal = new UI();
        uiCal.init();
    }

}



